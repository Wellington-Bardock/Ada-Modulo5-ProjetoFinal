package br.com.ada.projetomodulo5.dto.response;

import lombok.Data;

@Data
public class ProdutoResponse {

    private String uuid;
    private String nome;
    private Integer quantidade;

}
