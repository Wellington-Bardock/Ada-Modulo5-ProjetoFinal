package br.com.ada.projetomodulo5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoModulo5Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoModulo5Application.class, args);
	}

}
